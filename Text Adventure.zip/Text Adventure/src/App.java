
public class App {
	public static void main(String[] args) {
		Player.name();
		Game game = new Game();
		game.play();
	}
}

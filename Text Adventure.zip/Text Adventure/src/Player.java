import java.util.Scanner;

public class Player {
	private static int health;
	private static int loot;
	private static String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getLoot() {
		return loot;
	}
	public void setLoot(int loot) {
		this.loot = loot;
	}
	
	public static void name() {
		Scanner keyboardInput = new Scanner(System.in);
		System.out.println("In this text based adventure game you must navigate, survive and escape from a mysterious swamp. "
				+ "\nYou will be promted to make choices by entering keyword, shown in brackets i.e. (Leave), "
				+ "\nas a shorthand you can just use the initail of the keyword, i.e. (L), and nothing is case sensitive. "
				+ "\nWould you like to (Name) your character, or use the (Default)");
		String yes = keyboardInput.nextLine();
		if (yes.equalsIgnoreCase("N") || yes.equalsIgnoreCase("Name")) {
			System.out.println("Please name your charachter");
			String nam = keyboardInput.nextLine();
			System.out.println("Hello " + nam + " try not to die."
					+ "\nWould you like to (Set) your starting Health, or use the (Default)");
			String set = keyboardInput.nextLine();
			if (set.equalsIgnoreCase("S") || set.equalsIgnoreCase("set")) {
				System.out.println("Enter desired Health");
				int hel = keyboardInput.nextInt();
				choose(nam, hel);
			} else {
				choose(nam);
			}
		} else {
			choose();
		}		
	}
	
	public static void choose() {
		name = "Sam";
		health = 10;
	}
	public static void choose(String nam) {
		name = nam;
		health = 10;
	}
	public static void choose(String nam, int hel) {
		name = nam;
		health = hel;
		System.out.println(health);
	}
}


public class Empty extends Encounter {
	public void local() {
		System.out.println("You enter a dank patch of swamp much like all the rest, with nothing else to do you decide to move on.");
	}
}

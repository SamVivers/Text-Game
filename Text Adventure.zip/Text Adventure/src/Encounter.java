
abstract public class Encounter {
	abstract public void local();
}


public class Wisp extends Encounter{
	Player player = new Player();
	
	public void local() {
		System.out.println(player.getName() + " is attracted to a glowing Will o' the Wisp and follows it blindly into the deep swamp, "
				+ "\nnever to return...");
		player.setHealth(0);
	}
}

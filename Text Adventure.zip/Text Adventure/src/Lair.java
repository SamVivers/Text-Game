import java.util.Scanner;

public class Lair extends Encounter{
	Player player = new Player();
	
	public void local() {
		System.out.println("You see the embers of a cook fire at the mouth of dark cave, (Enter) the cave or (Leave)?");
		Scanner keyboardInput = new Scanner(System.in);
		String inv = keyboardInput.nextLine();
		if (inv.equalsIgnoreCase("E") || inv.equalsIgnoreCase("enter")) {
			int n = (int)(Math.random() * 3);
			if (n == 0) {
				System.out.println("The cave is deserted and you find nothing of interest");	
			} else if (n == 1) {
				System.out.println("The cave is deserted but you find some loot left by a previous traveller");
				player.setLoot(player.getLoot() + 1);
			} else {
				System.out.println("The cave seems deserted, then suddenly an Ogre bursts from the darkness wielding a heavy club, "
						+ "\ndo you (Fight) or (Run)?");
				String act = keyboardInput.nextLine();
				if (act.equalsIgnoreCase("F") || act.equalsIgnoreCase("Fight")) {
					System.out.println("You charge at the beast ducking under its club and a brutal close quarters scrap ensues.");
					int m = (int)(Math.random() * 2);
					if (m == 0) {
						System.out.println("The Ogre throws you free of it and, faster than you can react, swings its club");
						player.setHealth(0);
					} else {
						System.out.println("You land a fierce punch on the Ogre's nose knocking it out cold. "
								+ "\nYou gather the loot it had been hording and exit the cave");
						player.setLoot(player.getLoot() + 5);
					}
				} else {
					System.out.println("As you flee a shaprened stalactite catches you shoulder opening a nasty gash");
					player.setHealth(player.getHealth() - 1);
				}
			}			
		} else {
			System.out.println("Perhaps causion is a wise choice, you move on");
		}
	}		
}
